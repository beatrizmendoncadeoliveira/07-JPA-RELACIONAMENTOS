package br.com.fiap.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CalculadoraTest {

	
	
	@Test
	void somaTest() {
	Calculadora c=new Calculadora();
	
	int soma=c.soma(3,5);
	
	assertEquals(8, soma);
	
	
	}

}
