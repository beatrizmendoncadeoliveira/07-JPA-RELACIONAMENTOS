package br.com.fiap.test;

import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import br.com.fiap.jpa.dao.ContaDAO;
import br.com.fiap.jpa.dao.impl.ContaDAOImpl;
import br.com.fiap.jpa.entity.Conta;
import br.com.fiap.jpa.entity.Tipo;
import br.com.fiap.jpa.exception.CommitException;
import br.com.fiap.jpa.exception.KeyNotFoundException;

class ContaDAOTeste {

	// colocamos o DAO aqui para todos os metodos conseguirem enxergar ele
	static ContaDAO dao;
	 Conta conta;

	@BeforeAll // metodo que sera executado antes de todos os metodos
				// metodo estatico
	static void inicializar() {
		// Criar instancia Conta, ContaDAO, EntityManager, EntityMangerFactory
		EntityManagerFactory f = Persistence.createEntityManagerFactory("teste");
		EntityManager em = f.createEntityManager();
		dao = new ContaDAOImpl(em);
	}

	@BeforeEach // metodo de cadastro pq todos os outros metodos vao precisar cadastrar
	void cadastrar() {
		 conta = new Conta(1, Tipo.CORRENTE, 100, Calendar.getInstance());
		// cadastrar a conta
		dao.cadastrar(conta);
		try {
			dao.commit();
		} catch (Exception e) {
			fail("Falha no teste");
		}
	}
	
	@Test
	@DisplayName("Atualizacao de conta com sucesso")
	void atualizaSucessoTest() {
		conta.setTipo(Tipo.INVESTIMENTO);
		conta.setSaldo(999);
		dao.atualizar(conta);
		try {
			dao.commit();
		} catch (CommitException e) {
			fail("Falha nos testes");
		}
		
		try {
			//Pesquisa a conta
			Conta busca=dao.pesquisar(conta.getCodigo());
			//Valida se os dados foram alterados
			assertEquals(999,busca.getSaldo());
		} catch (KeyNotFoundException e) {
			fail("Falha nos testes");
		}
		
		
	}
	@Test
	@DisplayName("Remocao de conta com sucesso")
	void deletarSucessoTest() {
		try {
			dao.deletar(conta.getCodigo());
			dao.commit();
		} catch (KeyNotFoundException e) {
			fail("Falha no teste");
		} catch (CommitException e) {
			// TODO Auto-generated catch block
			fail("Falha no teste");
		}
		//valida se realmente apagou a conta
		//se o metodo lancar a excecao o teste funcionou
		assertThrows(KeyNotFoundException.class, () -> {dao.pesquisar(conta.getCodigo()); });

	}
	@Test
	@DisplayName("Pesquisa de conta com sucesso")
	 void  buscaSucessoTest() {
		//pesquisar a conta cadastrada (beforeEach)
		try {
			Conta busca=dao.pesquisar(conta.getCodigo());
			//validar se retornou a conta
			assertEquals(100, busca.getSaldo());//quero ver se o 100 do cadastro esta 100 mesmo
			assertEquals(1, busca.getAgencia());//quero ver se a agencia q cadastrei como 1 � 1 
			
		} catch (KeyNotFoundException e) {
			fail("Falha no teste");
		}
	}
	@Test
	@DisplayName("Cadastro de conta com sucesso")
	void cadastroSucessoTest() {
		assertNotEquals(0, conta.getCodigo());
	}

	
}
