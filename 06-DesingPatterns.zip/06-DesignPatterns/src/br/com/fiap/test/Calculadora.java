package br.com.fiap.test;

public class Calculadora {

	public int soma(int x, int y) {
		return x+y;
	}
}
