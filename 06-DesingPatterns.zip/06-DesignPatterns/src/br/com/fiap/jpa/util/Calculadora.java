package br.com.fiap.jpa.util;

public class Calculadora {

	public int somar(int x, int y) {
		return x + y;
	}
	
}
