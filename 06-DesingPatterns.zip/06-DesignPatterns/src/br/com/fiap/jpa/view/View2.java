package br.com.fiap.jpa.view;

import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.fiap.jpa.dao.ContaDAO;
import br.com.fiap.jpa.dao.GenericDAO;
import br.com.fiap.jpa.dao.impl.GenericDAOImpl;
import br.com.fiap.jpa.entity.Cargo;
import br.com.fiap.jpa.entity.Colaborador;
import br.com.fiap.jpa.entity.Conta;
import br.com.fiap.jpa.exception.CommitException;
import br.com.fiap.jpa.exception.KeyNotFoundException;
import br.com.fiap.jpa.singleton.EntityManagerFactorySingleton;

public class View2 {

	public static void main(String[] args) {
		//Instanciar a fabrica
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		//Instanciar o entity manager
		EntityManager em = fabrica.createEntityManager();
		
		//Utilizar o dao gen�rico sem precisar criar a classe e interface
		//instanciando uma classe anomima, filha do generic dao
		GenericDAO<Colaborador, Integer> dao = 
				new GenericDAOImpl<Colaborador, Integer>(em) {};
				
		try {
			Colaborador c = new Colaborador("Allen", Cargo.COORDENADOR, Calendar.getInstance(), 12000);
			dao.cadastrar(c);
			dao.commit();
		} catch (CommitException e) {
			System.out.println("Erro ao cadastrar..");
		}		
		
		//fechar as paradas
		em.close();
		fabrica.close();
	}
	
}