package br.com.fiap.jpa.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import br.com.fiap.jpa.dao.ContaDAO;
import br.com.fiap.jpa.dao.impl.ContaDAOImpl;
import br.com.fiap.jpa.entity.Conta;
import br.com.fiap.jpa.entity.Tipo;
import br.com.fiap.jpa.exception.CommitException;
import br.com.fiap.jpa.exception.KeyNotFoundException;

class ContaDAOTest {

	static ContaDAO dao;
	
	Conta conta;
	
	@BeforeAll //método que será executado antes de todos os testes
	static void inicializar() {
		//Criar uma instancia da Conta, ContaDAO, EntityManager, EntityManagerFactory
		EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("teste");
		EntityManager em = fabrica.createEntityManager();
		dao = new ContaDAOImpl(em);
	}
	
	@BeforeEach //método chamado antes de cada teste
	void cadastrar() {
		conta = new Conta(1,Tipo.CORRENTE, 100, Calendar.getInstance());
		
		//Cadastrar a conta
		dao.cadastrar(conta);
		try {
			dao.commit();
		} catch (CommitException e) {
			fail("Falha no teste");
		}
	}
	
	@Test
	@DisplayName("Remove uma conta com sucesso")
	void deletaSucessoTest() {
		//Apaga a conta
		try {
			dao.deletar(conta.getCodigo());
			dao.commit();
		} catch (KeyNotFoundException | CommitException e) {
			fail("Falha no teste");
		}
		//Valida se realmente apagou a conta
		//se o método lançar a exceção o teste funcionou
		assertThrows(KeyNotFoundException.class, () -> { dao.pesquisar(conta.getCodigo()); });
	}
	
	@Test
	@DisplayName("Atualização de conta com sucesso")
	void atualizaSucessoTest() {
		//Atualiza alguns campos da conta
		conta.setTipo(Tipo.INVESTIMENTO);
		conta.setSaldo(999);
		
		dao.atualizar(conta);
		try {
			dao.commit();
		} catch (CommitException e) {
			fail("Falha no teste");
		}
		
		try {
			//Pesquisa a conta
			Conta busca = dao.pesquisar(conta.getCodigo());
			
			//Valida se os dados foram alterados
			assertEquals(Tipo.INVESTIMENTO, busca.getTipo());
			assertEquals(999, busca.getSaldo());
			
		} catch (KeyNotFoundException e) {
			fail("Falha no teste");
		}
	}
	
	@Test
	@DisplayName("Pesquisa de conta com sucesso")
	void buscaSucessoTest() {
		try {
			//pesquisar a conta cadastrada
			Conta busca = dao.pesquisar(conta.getCodigo());
			//validar se retornou a conta
			assertEquals(100, busca.getSaldo());
			assertEquals(1, busca.getAgencia());
			assertEquals(conta.getCodigo(), busca.getCodigo());
		} catch (KeyNotFoundException e) {
			fail("Falha no teste");
		}
	}
	
	@Test
	@DisplayName("Cadastro de conta com sucesso")
	void cadastroSucessoTest() {
		//Validar se foi cadastrado com sucesso
		assertNotEquals(0, conta.getCodigo()); //valida se gerou um código para a conta
	}

}
