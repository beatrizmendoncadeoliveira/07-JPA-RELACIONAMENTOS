package br.com.fiap.jpa.singleton;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Classe que gerencia a Fabrica de Entity Manager,
 * permitindo somente uma �nica inst�ncia da fabrica
 */
public class EntityManagerFactorySingleton {

	//atributo est�tico que armazena a �nica inst�ncia
	private static EntityManagerFactory fabrica;
	
	//construtor privado -> n�o � poss�vel instanciar a classe
	private EntityManagerFactorySingleton() {}
	
	//m�todo est�tico que retorna a �nica inst�ncia
	public static EntityManagerFactory getInstance() {
		if (fabrica == null) {
			fabrica = Persistence.createEntityManagerFactory("oracle");
		}
		return fabrica;
	}
	
}
