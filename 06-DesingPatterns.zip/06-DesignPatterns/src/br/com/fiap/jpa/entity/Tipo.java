package br.com.fiap.jpa.entity;

public enum Tipo {

	CORRENTE, POUPANCA, INVESTIMENTO
	
}
