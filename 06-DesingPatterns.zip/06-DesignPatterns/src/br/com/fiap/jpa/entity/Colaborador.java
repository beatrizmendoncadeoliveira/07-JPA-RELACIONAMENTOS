package br.com.fiap.jpa.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="TB_COLABORADOR")
@SequenceGenerator(name="col",sequenceName = "SQ_TB_COLABORADOR", allocationSize = 1)
public class Colaborador {

	@Id
	@Column(name="cd_colaborador")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "col")
	private int codigo;
	
	@Column(name="nm_colaborador", nullable = false, length = 100)
	private String nome;
	
	@Enumerated(EnumType.STRING)
	@Column(name="ds_cargo")
	private Cargo cargo;
	
	@Temporal(TemporalType.DATE)
	@Column(name="dt_admissao")
	private Calendar dataAdmissao;
	
	@Column(name="vl_salario")
	private float salario;

	public Colaborador(String nome, Cargo cargo, Calendar dataAdmissao, float salario) {
		super();
		this.nome = nome;
		this.cargo = cargo;
		this.dataAdmissao = dataAdmissao;
		this.salario = salario;
	}

	public Colaborador() {
		super();
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Cargo getCargo() {
		return cargo;
	}

	public void setCargo(Cargo cargo) {
		this.cargo = cargo;
	}

	public Calendar getDataAdmissao() {
		return dataAdmissao;
	}

	public void setDataAdmissao(Calendar dataAdmissao) {
		this.dataAdmissao = dataAdmissao;
	}

	public float getSalario() {
		return salario;
	}

	public void setSalario(float salario) {
		this.salario = salario;
	}
	
}
