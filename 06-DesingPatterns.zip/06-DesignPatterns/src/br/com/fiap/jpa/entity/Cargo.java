package br.com.fiap.jpa.entity;

public enum Cargo {

	ANALISTA, DESENVOLVEDOR, COORDENADOR, GERENTE 
}
