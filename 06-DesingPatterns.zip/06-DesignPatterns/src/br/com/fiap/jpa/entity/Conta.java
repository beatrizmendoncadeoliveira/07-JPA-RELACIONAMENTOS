package br.com.fiap.jpa.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="TB_CONTA")
@SequenceGenerator(name="conta", sequenceName = "SQ_TB_CONTA", allocationSize = 1)
public class Conta {

	@Id
	@Column(name="cd_conta")
	@GeneratedValue(generator = "conta", strategy = GenerationType.SEQUENCE)
	private int codigo;
	
	@Column(name="nr_agencia", nullable = false)
	private int agencia;
	
	@Column(name="ds_tipo")
	@Enumerated(EnumType.STRING)
	private Tipo tipo;
	
	@Column(name="vl_saldo")
	private float saldo;

	@Temporal(TemporalType.DATE)
	@Column(name="dt_abertura")
	private Calendar dataAbertura;
	
	public Conta() {
		super();
	}

	public Conta(int agencia, Tipo tipo, float saldo, Calendar dataAbertura) {
		super();
		this.agencia = agencia;
		this.tipo = tipo;
		this.saldo = saldo;
		this.dataAbertura = dataAbertura;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public int getAgencia() {
		return agencia;
	}

	public void setAgencia(int agencia) {
		this.agencia = agencia;
	}

	public Tipo getTipo() {
		return tipo;
	}

	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}

	public float getSaldo() {
		return saldo;
	}

	public void setSaldo(float saldo) {
		this.saldo = saldo;
	}

	public Calendar getDataAbertura() {
		return dataAbertura;
	}

	public void setDataAbertura(Calendar dataAbertura) {
		this.dataAbertura = dataAbertura;
	}
	
}
