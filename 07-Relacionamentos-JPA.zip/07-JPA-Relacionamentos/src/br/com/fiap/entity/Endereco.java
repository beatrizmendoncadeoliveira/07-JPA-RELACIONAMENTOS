package br.com.fiap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TB_ENDERECO")
@SequenceGenerator(allocationSize = 1,name = "cod",sequenceName = "seq_cod")
public class Endereco {
	@Id
	@GeneratedValue(generator = "cod",strategy = GenerationType.SEQUENCE)
	@Column(name="cd_endereco")
	private int codigo;
	@Column(name="ds_logradouro", nullable=false, length=40)
	private String logradouro;
	@Column(name="ds_tipo", nullable=false, length=40)
	private String descricao;
	@Column(name="nr_endereco")
	private int numero;
	
	
	
	
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	

}
