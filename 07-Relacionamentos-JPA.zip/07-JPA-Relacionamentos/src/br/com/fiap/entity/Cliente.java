package br.com.fiap.entity;

import java.util.Calendar;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@SequenceGenerator(allocationSize = 1,sequenceName = "seq_cod",name = "cod")
@Table(name = "TB_CLIENTE")
public class Cliente {
	@Id
	@GeneratedValue(generator = "cod", strategy = GenerationType.SEQUENCE)
	@Column(name = "cd_cliente")
	private int codigo;
	@Column(name="nm_cliente", nullable=false, length=40)
	private String nome;
	@Column(name = "ds_sobrenome", nullable=false, length=40)
	private String sobrenome;
	@Column(name="dt_nascimento")
	@Temporal(TemporalType.DATE)
	private Calendar data_nasc;
	
	//mapeamento bidirecional usa  o mappedBy->Mapeia a outra classe 
	//cascade realiza as operacoes em cascata(nos relacionamentos)
	//fetch,lazy-adia o maximo o carregamento, eager-carrega o login no mesmo tempo que o cliente
	@OneToOne(mappedBy = "cliente", cascade=CascadeType.ALL, fetch=FetchType.LAZY)
	private Login login;
	//Relacionamento bidirecional precisa do mappebY, nome do atributo do outro lado
	@OneToMany(mappedBy = "cliente")
	private List<Pedido> pedidos;
	
	public int getCodigo() { 
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSobrenome() {
		return sobrenome;
	}
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	public Calendar getData_nasc() {
		return data_nasc;
	}
	public void setData_nasc(Calendar data_nasc) {
		this.data_nasc = data_nasc;
	}
	public Login getLogin() {
		return login;
	}
	public void setLogin(Login login) {
		this.login = login;
	}
	
	

}
