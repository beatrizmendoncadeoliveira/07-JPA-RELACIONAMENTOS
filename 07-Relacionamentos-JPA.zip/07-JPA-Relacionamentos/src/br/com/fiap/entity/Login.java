package br.com.fiap.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@SequenceGenerator(allocationSize = 1,name = "cod",sequenceName = "seq_cod")
@Table(name="TB_LOGIN")
public class Login {
	@Id
	@GeneratedValue(generator = "cod",strategy = GenerationType.SEQUENCE)
	@Column(name="cd_codigo")
	private int codigo;
	@Column(name="cd_cliente")
	private int codigo_cliente;
	@Column(name="ds_senha", nullable=false, length=40)
	private String senha;
	@Column(name="nm_login", nullable=false, length=40)
	private String login;
	
	//mapear relacionamento 1-p-1
	//fetch-lazy-adia o maximo o carregamento, eager- carrega o cliente no mesmo momento do login
	@OneToOne(cascade=CascadeType.ALL, fetch=FetchType.LAZY)
	@JoinColumn(name="cd_cliente")
	private Cliente cliente;
	//criar get e set do cliente-ok
	
	
	
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public int getCodigo_cliente() {
		return codigo_cliente;
	}
	public void setCodigo_cliente(int codigo_cliente) {
		this.codigo_cliente = codigo_cliente;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	
	

}
