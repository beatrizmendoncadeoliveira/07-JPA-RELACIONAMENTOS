package br.com.fiap.entity;

import java.util.Calendar;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="TB_PEDIDO")
@SequenceGenerator(allocationSize = 1,name = "cod",sequenceName = "seq_cod")
public class Pedido {
	@Id
	@Column(name="cd_pedido")
	@GeneratedValue(generator = "cod",strategy = GenerationType.SEQUENCE)
	private int codigo;
	@Column(name="cd_cliente")
	private int codigo_cliente;
	@Column(name="vl_pedido", nullable=false, length=40)
	private double valor;
	@Column(name="qt_pedido", nullable=false, length=40)
	private int quantidade;
	@Column(name="dt_pedido")
	@Temporal(TemporalType.TIMESTAMP)
	private Calendar data;
	
	@ManyToOne(cascade= {CascadeType.PERSIST, CascadeType.MERGE}, fetch=FetchType.EAGER)
	@JoinColumn(name="cd_cliente", nullable=false)
	private Cliente cliente;
	
	
	
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public int getCodigo_cliente() {
		return codigo_cliente;
	}
	public void setCodigo_cliente(int codigo_cliente) {
		this.codigo_cliente = codigo_cliente;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	public Calendar getData() {
		return data;
	}
	public void setData(Calendar data) {
		this.data = data;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	

}
